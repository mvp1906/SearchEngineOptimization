document.addEventListener("DOMContentLoaded", function() {
    const elementsToFade = document.querySelectorAll('.fade-in');
    const elementsToSlideUp = document.querySelectorAll('.slide-up');
    const ctaButtons = document.querySelectorAll('.cta-button');

    // Check if an element is in the viewport
    const isElementInViewport = (el) => {
        const rect = el.getBoundingClientRect();
        return rect.top <= window.innerHeight && rect.bottom >= 0;
    };

    // Animate elements on scroll
    const animateOnScroll = () => {
        elementsToFade.forEach(element => {
            if (isElementInViewport(element)) {
                element.classList.add('visible');
            }
        });

        elementsToSlideUp.forEach(element => {
            if (isElementInViewport(element)) {
                element.classList.add('visible');
            }
        });

        ctaButtons.forEach(button => {
            if (isElementInViewport(button)) {
                button.classList.add('visible');
            }
        });
    };

    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Initial check in case the elements are already in view
});


document.addEventListener("DOMContentLoaded", function() {
    const elementsToFade = document.querySelectorAll('.fade-in');
    const elementsToSlideUp = document.querySelectorAll('.slide-up');
    const ctaButtons = document.querySelectorAll('.cta-button');

    // Check if an element is in the viewport
    const isElementInView = (element) => {
        const rect = element.getBoundingClientRect();
        return rect.top >= 0 && rect.bottom <= window.innerHeight;
    };

    // Fade-in elements when they come into view
    const fadeInElements = () => {
        elementsToFade.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });
    };

    // Slide-up elements when they come into view
    const slideUpElements = () => {
        elementsToSlideUp.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });
    };

    // Scroll Event Listener
    window.addEventListener('scroll', () => {
        fadeInElements();
        slideUpElements();
    });

    // Initial check if elements are already in view
    fadeInElements();
    slideUpElements();
});

document.addEventListener("DOMContentLoaded", function() {
    // Select the elements we want to animate
    const fadeElements = document.querySelectorAll('.fade-in');
    const slideElements = document.querySelectorAll('.slide-up');

    // Function to check if an element is in the viewport
    const isElementInView = (element) => {
        const rect = element.getBoundingClientRect();
        return rect.top >= 0 && rect.bottom <= window.innerHeight;
    };

    // Add 'visible' class when the element comes into view
    const handleScrollAnimations = () => {
        fadeElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });

        slideElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });
    };

    // Listen for the scroll event
    window.addEventListener('scroll', handleScrollAnimations);

    // Initial check to add animations to already visible elements on page load
    handleScrollAnimations();
});


document.addEventListener("DOMContentLoaded", function() {
    // Select the elements that should be animated
    const fadeElements = document.querySelectorAll('.fade-in');
    const slideElements = document.querySelectorAll('.slide-up');

    // Function to check if an element is in the viewport
    const isElementInView = (element) => {
        const rect = element.getBoundingClientRect();
        return rect.top >= 0 && rect.bottom <= window.innerHeight;
    };

    // Function to handle scroll animations
    const handleScrollAnimations = () => {
        fadeElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });

        slideElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });
    };

    // Listen for scroll events
    window.addEventListener('scroll', handleScrollAnimations);

    // Initial check in case elements are already in view on page load
    handleScrollAnimations();
});

document.addEventListener("DOMContentLoaded", function() {
    // Function to handle scroll animations
    const fadeElements = document.querySelectorAll('.fade-in');
    const slideElements = document.querySelectorAll('.slide-up');

    // Check if element is in the viewport
    function isElementInView(element) {
        const rect = element.getBoundingClientRect();
        return rect.top >= 0 && rect.bottom <= window.innerHeight;
    }

    // Add visible class when elements are in view
    function handleScrollAnimations() {
        fadeElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });

        slideElements.forEach(element => {
            if (isElementInView(element)) {
                element.classList.add('visible');
            }
        });
    }

    // Initial check in case elements are already in view on page load
    handleScrollAnimations();

    // Listen for scroll events
    window.addEventListener('scroll', handleScrollAnimations);
});